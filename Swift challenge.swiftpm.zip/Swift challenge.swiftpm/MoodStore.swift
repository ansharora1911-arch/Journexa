import Foundation

class MoodStore: ObservableObject {
    
    @Published var weeklyScores: [Int] {
        didSet {
            UserDefaults.standard.set(weeklyScores, forKey: "weeklyScores")
        }
    }
    
    init() {
        weeklyScores = UserDefaults.standard.array(forKey: "weeklyScores") as? [Int] ?? []
    }
    
    private let positiveWords = [
        "happy": 2, "great": 2, "productive": 3,
        "excited": 2, "good": 1, "amazing": 3,
        "grateful": 2
    ]
    
    private let negativeWords = [
        "sad": -2, "tired": -1, "stressed": -3,
        "angry": -2, "bad": -1, "upset": -2,
        "anxious": -3
    ]
    
    func analyzeMood(from text: String) -> MoodResult {
        
        let lower = text.lowercased()
        var score = 0
        
        for (word, weight) in positiveWords {
            if lower.contains(word) { score += weight }
        }
        
        for (word, weight) in negativeWords {
            if lower.contains(word) { score += weight }
        }
        
        weeklyScores.append(score)
        
        let level: MoodLevel
        
        if score <= -2 {
            level = .low
        } else if score <= 2 {
            level = .neutral
        } else {
            level = .high
        }
        
        return MoodResult(score: score, level: level)
    }
}
