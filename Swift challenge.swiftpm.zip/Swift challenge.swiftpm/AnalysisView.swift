import SwiftUI

struct AnalysisView: View {
    
    @EnvironmentObject var moodStore: MoodStore
    @EnvironmentObject var userProfile: UserProfile
    
    var journalText: String
    
    @State private var animate = false
    @State private var result: MoodResult? = nil
    
    var body: some View {
        
        ZStack {
            
            backgroundGradient()
                .ignoresSafeArea()
            
            VStack(spacing: 40) {
                
                Spacer()
                
                Text("How to Make Your Day Better")
                    .font(.largeTitle)
                    .bold()
                    .foregroundColor(.white)
                    .scaleEffect(animate ? 1 : 0.8)
                    .opacity(animate ? 1 : 0)
                    .animation(.spring(response: 0.7, dampingFraction: 0.7), value: animate)
                
                moodEmoji()
                    .font(.system(size: 70))
                    .scaleEffect(animate ? 1 : 0.5)
                    .animation(.easeOut(duration: 0.8), value: animate)
                
                Text(personalizedSuggestion())
                    .font(.title3)
                    .multilineTextAlignment(.center)
                    .foregroundColor(.white)
                    .padding()
                
                moodMeter()
                
                Spacer()
            }
            .padding()
        }
        .onAppear {
            animate = true
            result = moodStore.analyzeMood(from: journalText)
        }
        .onChange(of: journalText) { newValue in
            result = moodStore.analyzeMood(from: newValue)
        }
    }
    
    // MARK: - Background
    
    func backgroundGradient() -> LinearGradient {
        guard let result = result else {
            return LinearGradient(colors: [.gray, .gray],
                                  startPoint: .topLeading,
                                  endPoint: .bottomTrailing)
        }
        switch result.level {
        case .low:
            return LinearGradient(colors: [.blue, .indigo],
                                  startPoint: .topLeading,
                                  endPoint: .bottomTrailing)
        case .neutral:
            return LinearGradient(colors: [.purple, .pink],
                                  startPoint: .topLeading,
                                  endPoint: .bottomTrailing)
        case .high:
            return LinearGradient(colors: [.orange, .yellow],
                                  startPoint: .topLeading,
                                  endPoint: .bottomTrailing)
        }
    }
    
    // MARK: - Emoji
    
    func moodEmoji() -> Text {
        guard let result = result else { return Text("⌛️") }
        switch result.level {
        case .low: return Text("😔")
        case .neutral: return Text("🙂")
        case .high: return Text("😄")
        }
    }
    
    // MARK: - Suggestion
    
    func personalizedSuggestion() -> String {
        guard let result = result else { return "Analyzing your mood…" }
        
        switch result.level {
            
        case .low:
            return "Hey \(userProfile.name), maybe try \(userProfile.favoriteActivity). Small steps can shift your mood."
            
        case .neutral:
            return "You're steady today. Some \(userProfile.favoriteMusic) might boost your energy."
            
        case .high:
            return "Amazing energy! Celebrate with \(userProfile.relaxationMethod)."
        }
    }
    
    // MARK: - Mood Meter
    
    func moodMeter() -> some View {
        VStack {
            Text("Mood Intensity")
                .foregroundColor(.white.opacity(0.8))
            
            if let result = result {
                ProgressView(value: Double(result.score + 5), total: 10)
                    .tint(.white)
                    .padding(.horizontal)
            } else {
                ProgressView()
                    .tint(.white)
                    .padding(.horizontal)
            }
        }
    }
}

