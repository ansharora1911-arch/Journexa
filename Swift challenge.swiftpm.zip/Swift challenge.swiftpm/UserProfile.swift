import Foundation

class UserProfile: ObservableObject {
    
    @Published var name: String {
        didSet { UserDefaults.standard.set(name, forKey: "name") }
    }
    
    @Published var favoriteActivity: String {
        didSet { UserDefaults.standard.set(favoriteActivity, forKey: "activity") }
    }
    
    @Published var favoriteMusic: String {
        didSet { UserDefaults.standard.set(favoriteMusic, forKey: "music") }
    }
    
    @Published var relaxationMethod: String {
        didSet { UserDefaults.standard.set(relaxationMethod, forKey: "relax") }
    }
    
    @Published var isOnboarded: Bool {
        didSet { UserDefaults.standard.set(isOnboarded, forKey: "onboarded") }
    }
    
    init() {
        name = UserDefaults.standard.string(forKey: "name") ?? ""
        favoriteActivity = UserDefaults.standard.string(forKey: "activity") ?? ""
        favoriteMusic = UserDefaults.standard.string(forKey: "music") ?? ""
        relaxationMethod = UserDefaults.standard.string(forKey: "relax") ?? ""
        isOnboarded = UserDefaults.standard.bool(forKey: "onboarded")
    }
}
